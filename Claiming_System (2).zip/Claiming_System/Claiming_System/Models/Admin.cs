﻿namespace Claiming_System.Models
{
    public class Admin
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
